﻿This is EMU8086 version 4.08
Repack for Windows 10
November 25, 2015


user: ic0n0statse
key: CSEJHFVZ3FRTQZXJKASA

User: ISHAAN,glaitm
Key: 27R3VDEFYFX4N0VC3FRTQZX